package com.korea.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex0621DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
