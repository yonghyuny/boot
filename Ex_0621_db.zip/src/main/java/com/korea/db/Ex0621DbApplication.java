package com.korea.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex0621DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex0621DbApplication.class, args);
	}

}
