package com.korea.tier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex0621TierApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex0621TierApplication.class, args);
	}

}
