package com.korea.tier.service;

import com.korea.tier.vo.OrderVO;

public interface OrderService {

	//주문하기
	public void order(OrderVO orderVO);
}
