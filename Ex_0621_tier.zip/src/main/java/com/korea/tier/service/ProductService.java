package com.korea.tier.service;

import java.util.List;

import com.korea.tier.vo.ProductVO;

public interface ProductService {
	//컨트롤러 하나에 하나의 쿼리가 나가기 때문에 서비스에 대한 목적이 두드러지진 않는다.
	//여러개를 연동하다보면 하나의 서비스에 여러개의 쿼리가 필요하다 보니 하나의 메서드로
	//묶어서 처리하기위해 존재한다.

	//상품 추가
	public void regiseter(ProductVO productVO);
	
	//상품조회
	public List<ProductVO> getList();
}







